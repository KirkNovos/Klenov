﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vosmerka
{
    class Class1
    {
        public static dmininEntities DB = new dmininEntities();
    }
}
